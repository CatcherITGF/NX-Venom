# HOT WHEELS UNLEASHED 2

> Game info

TitleID: `01001BE01908C000`<br>
Explanation based on:
- Internal version: `1.0.1`, 
- Nintendo version ID: `v1`/`v65536`
- BID: `012294C1E2D28A79`
- Engine: `Unreal Engine 4.27.2`

> Details

Game can be unlocked to 60 FPS with plugin alone, but because game is using dynamic resolution set to 33.33 ms, performance is subpar. Requires patch to fix that.
It is recommended to disable FSR. When FSR is enabled, dynamic Resolution is also disabled and it has worse performance at higher FPS, and quality wise it compares to dynamic resolution set to lowest res.
