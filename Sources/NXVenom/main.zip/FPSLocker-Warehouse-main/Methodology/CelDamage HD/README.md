# Cel Damage HD

> Game info

TitleID: `010019B00BE72000`<br>
Explanation based on:
- Internal version: `1.0.0`, 
- Nintendo version ID: `v0`
- BID: `03B058B1F6BE7195`
- Engine: Proprietary

> Details

SaltyNX doesn't support 32-bit games. For 60 FPS cheat look [HERE](https://github.com/ChanseyIsTheBest/NX-60FPS-RES-GFX-Cheats/blob/main/titles/010019B00BE72000/cheats/03B058B1F6BE7195.txt)
