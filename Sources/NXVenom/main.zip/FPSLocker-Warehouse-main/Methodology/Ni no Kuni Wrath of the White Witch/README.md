# Ni no Kuni: Wrath of the White Witch

> Game info

TitleID: `0100E5600D446000`<br>
Explanation based on:
- Internal version: `1.0.2`, 
- Nintendo version ID: `v2`/`v131072`
- BID: `C32B29CB5FBA96D9`
- Engine: Level-5 proprietary engine

> Details

SaltyNX doesn't support 32-bit games. For 60 FPS read [THIS](https://gbatemp.net/threads/ni-no-kuni-wrath-of-the-white-witch-60-fps-hack.558225/)
