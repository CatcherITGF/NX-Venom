# DAEMON X MACHINA

> Game info

TitleID: `0100B6400CA56000`<br>
Explanation based on:
- Internal version: `1.4.2a`, 
- Nintendo version ID: `v12`/`v786432`
- BID: `937209E79E2E0E5D`
- Engine: `Unreal Engine 4.20.3`

> Details

Game is using internal FPS lock + dynamic resolution set to 33.3 ms, performance is subpar. Requires patch to fix that.
After setting FPS above 30 physics are broken. Max movement speed is lowered up to 2x at 60 FPS, mecha is descending up to 10x faster at 60 FPS.