# GOD WARS The Complete Legend

> Game info

TitleID: `0100F3D00B032000`<br>
Explanation based on:
- Internal version: `1.1`, 
- Nintendo version ID: `v1/v65536`
- BID: `3A0835D09F6D1544`
- Engine: NIS proprietary engine

> Details

Plugin allows going above 30 FPS. Movement speed is tied to framerate, though for a turn based game I don't consider it game breaking.