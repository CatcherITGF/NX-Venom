# Pokemon Mystery Dungeon: Rescue Team DX

> Game info

TitleID: `01003D200BAA2000`<br>
Explanation based on:
- Internal version: `1.0.2`, 
- Nintendo version ID: `v2`/`v131072`
- BID: `3AB632DEE82D5944`
- Engine: `Unity 2018.3.12`

> Details

Plugin alone allows going above 30 FPS. Character movement speed is tied to framerate, so at 60 FPS your character moves between tiles 2x faster. But because of how gameplay is designed, I don't consider it game-breaking.