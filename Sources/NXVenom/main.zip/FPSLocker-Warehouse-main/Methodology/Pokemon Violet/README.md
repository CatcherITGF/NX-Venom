# Pokemon Violet

> Game info

TitleID: `01008F6008C5E000`<br>
Explanation based on:
- Internal version: `1.3.0`, 
- Nintendo version ID: `v4`/`v262144`
- BID: `AC70E41BB699CB9F`
- Engine: proprietary

> Details

Game can be unlocked to 60 FPS with plugin alone, but because game speed is tied to framerate, we need to patch it. After applying game speed cheat character model is jumping between where it should be and where is it, causing stuttering. This game requires more work to do than just unlocking FPS and setting game speed.
