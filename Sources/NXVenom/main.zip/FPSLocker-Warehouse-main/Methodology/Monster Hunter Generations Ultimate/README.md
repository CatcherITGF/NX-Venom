# Monster Hunter Generations Ultimate

> Game info

TitleID: `0100770008DD8000`<br>
Explanation based on:
- Internal version: `1.4.0`, 
- Nintendo version ID: `v4`/`v262144`
- BID: `FB08F1D20FD1204F`
- Engine: `MT Framework`

> Details

SaltyNX doesn't support 32-bit games. For 60 FPS read [THIS](https://gbatemp.net/threads/monster-hunter-generations-ultimate-60-fps-hack.553053/)
