# South Park: The Stick of Truth

> Game info

TitleID: `010043600B6A6000`<br>
Explanation based on:
- Internal version: `1.01`, 
- Nintendo version ID: `v1`/`v65536`
- BID: `5BEA90B5335C9B60`
- Engine: `Autodesk GAMEWARE`

> Details

Game is using internal FPS Lock + double buffer. It's possible to set triple buffer, but internal FPS lock was not found.
