# Shin Megami Tensei III Nocturne HD Remaster

> Game info

TitleID: `01003B0012DC2000`<br>
Explanation based on:
- Internal version: `1.0.3`, 
- Nintendo version ID: `v3`/`v196608`
- BID: `F8098979DBC7F34E`
- Engine: `Unity 2019.4.10`

> Details

Plugin alone can set FPS above 30, but movement speed is tied to framerate, so at 60 FPS everything that you can control and move in 3D space is moving at 2x speed. Animation speed is adjusted to FPS.
