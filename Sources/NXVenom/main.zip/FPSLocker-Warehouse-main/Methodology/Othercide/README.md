# Othercide

> Game info

TitleID: `0100E5900F49A000`<br>
Explanation based on:
- Internal version: `1.3.0.5`, 
- Nintendo version ID: `v3`/`v196608`
- BID: `A8BA2A8F93AAE647`
- Engine: `Unity 2019.3.10`

> Details

Dynamic resolution timing is stored in read only section, thus why it's not possible to write FPSLocker patch.
For 60 FPS cheat with fixed dynamic resolution look [HERE](https://github.com/ChanseyIsTheBest/NX-60FPS-RES-GFX-Cheats/blob/main/titles/0100E5900F49A000/cheats/A8BA2A8F93AAE647.txt)