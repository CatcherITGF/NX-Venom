# GetsuFumaDen: Undying Moon

> Game info

TitleID: `010042A013DB8000`<br>
Explanation based on:
- Internal version: `1.1.1`, 
- Nintendo version ID: `v2`/`v131072`
- BID: `8683E654CCD68852`
- Engine: `Unreal Engine 4.27.1`

> Details

Plugin alone can set FPS above 30, but game is using dynamic resolution, so would be nice to patch it. But it's not using r.DynamicRes for that, so I don't know what to patch.